<?php
class Helper_ViewTest_Krco_EcommerceCart extends Helper_ViewTest_Krco_Cart
{
}
