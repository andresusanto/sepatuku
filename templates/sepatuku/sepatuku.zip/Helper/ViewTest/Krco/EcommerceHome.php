<?php
class Helper_ViewTest_Krco_EcommerceHome extends Helper_ViewTest_Krco_Home
{
}
