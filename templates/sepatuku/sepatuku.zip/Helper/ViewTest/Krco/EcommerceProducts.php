<?php
class Helper_ViewTest_Krco_EcommerceProducts extends Helper_ViewTest_Krco_Products
{
}
