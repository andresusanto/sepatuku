<?php
function smarty_modifier_cc_texts_to_options($texts) {
    return Helper_Structure::getOptionsFromTexts($texts);
} 
