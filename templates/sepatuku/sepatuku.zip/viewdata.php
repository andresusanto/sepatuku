<?php

header('Content-Type: application/json');

include "$scenario"; 
